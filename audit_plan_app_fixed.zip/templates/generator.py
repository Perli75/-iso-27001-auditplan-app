from docx import Document
from datetime import datetime

def generate_audit_plan(org_name, audit_type, employee_count, site_count, scope, soa_version, date):
    doc = Document()
    doc.add_heading("ISO 27001 Audit Plan", level=1)
    doc.add_paragraph(f"Company Name: {org_name}")
    doc.add_paragraph(f"Type of Audit: {audit_type}")
    doc.add_paragraph(f"Audit Date: {date.strftime('%d/%m/%Y')}")
    doc.add_paragraph(f"Employee Count: {employee_count}")
    doc.add_paragraph(f"Site Count: {site_count}")
    doc.add_paragraph(f"Scope: {scope}")
    doc.add_paragraph(f"Statement of Applicability: {soa_version}")
    doc.add_page_break()
    doc.add_heading("Audit Activities – Day 1", level=2)
    doc.add_paragraph("Sample audit schedule and clauses will go here...")
    output_path = f"app/outputs/{org_name.replace(' ', '_')}_AuditPlan.docx"
    doc.save(output_path)
